<?php
   session_start();
   session_destroy();
   header("LOCATION:https://classdb.it.mtu.edu/~krburns/finalproject/home.html");
?>